//
//  config.h
//  OGGZ
//
//  Created by Kenny Roethel on 4/10/13.
//  Copyright (c) 2013 Mindgrub Technologies. All rights reserved.
//

#ifndef OGGZ_config_h
#define OGGZ_config_h

#ifndef _LOFF_T_DEFINED
#define _LOFF_T_DEFINED
typedef long long loff_t;
#endif

#endif
